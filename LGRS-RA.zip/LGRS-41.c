// LGRS-41.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-41 - Numero Primo (while)                  *\n");
    printf("************************************************************\n\n");

    int numero, i = 2, primo = 1;

    printf("Digite um numero: ");
    scanf("%d", &numero);

    if (numero < 2) {
        primo = 0;
    } else {
        while (i < numero) {
            if (numero % i == 0) {
                primo = 0;
                break;
            }
            i++;
        }
    }

    if (primo) {
        printf("\nO numero %d E PRIMO.\n", numero);
    } else {
        printf("\nO numero %d NAO e primo.\n", numero);
    }

    return 0;
}
