// LGRS-36.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-36 - Contar de 1 a 10 (while)              *\n");
    printf("************************************************************\n\n");

    int i = 1;

    printf("Contagem de 1 a 10:\n");
    while (i <= 10) {
        printf("%d\n", i);
        i++;
    }

    return 0;
}
