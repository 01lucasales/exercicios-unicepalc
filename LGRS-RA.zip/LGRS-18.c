// LGRS-18.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-18 - Login Simples                         *\n");
    printf("************************************************************\n\n");

    char usuario[50], senha[50];
    char usuarioCorreto[] = "aluno";
    char senhaCorreta[]   = "biblioteca123";

    printf("Usuario: ");
    scanf("%s", usuario);
    printf("Senha: ");
    scanf("%s", senha);

    if (strcmp(usuario, usuarioCorreto) == 0 && strcmp(senha, senhaCorreta) == 0) {
        printf("\nAcesso PERMITIDO! Bem-vindo a biblioteca digital.\n");
    } else {
        printf("\nAcesso NEGADO! Usuario ou senha incorretos.\n");
    }

    return 0;
}
