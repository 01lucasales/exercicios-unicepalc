// LGRS-51.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-51 - Contagem Regressiva (do...while)      *\n");
    printf("************************************************************\n\n");

    int i = 10;

    printf("Contagem regressiva:\n");
    do {
        printf("%d\n", i);
        i--;
    } while (i >= 1);

    printf("VAI!\n");

    return 0;
}
