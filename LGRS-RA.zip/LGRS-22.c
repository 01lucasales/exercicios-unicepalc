// LGRS-22.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-22 - Par ou Impar                          *\n");
    printf("************************************************************\n\n");

    int numero;

    printf("Digite um numero inteiro: ");
    scanf("%d", &numero);

    if (numero % 2 == 0) {
        printf("\nO numero %d e PAR.\n", numero);
    } else {
        printf("\nO numero %d e IMPAR.\n", numero);
    }

    return 0;
}
