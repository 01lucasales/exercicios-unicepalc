// LGRS-37.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-37 - Soma ate Digitar Zero (while)         *\n");
    printf("************************************************************\n\n");

    float numero, soma = 0;

    printf("Digite numeros para somar (0 para encerrar):\n");
    printf("Numero: ");
    scanf("%f", &numero);

    while (numero != 0) {
        soma += numero;
        printf("Numero: ");
        scanf("%f", &numero);
    }

    printf("\nSoma total: %.2f\n", soma);

    return 0;
}
