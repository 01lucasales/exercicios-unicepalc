// LGRS-52.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-52 - Soma ate Multiplo de 10 (do...while)  *\n");
    printf("************************************************************\n\n");

    float numero, soma = 0;

    do {
        printf("Digite um numero: ");
        scanf("%f", &numero);
        soma += numero;
    } while ((int)numero % 10 != 0);

    printf("\nSoma total: %.2f\n", soma);

    return 0;
}
