// LGRS-32.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-32 - Quadrado dos Numeros de 1 a 10 (for)  *\n");
    printf("************************************************************\n\n");

    int i;

    printf("Quadrados de 1 a 10:\n");
    for (i = 1; i <= 10; i++) {
        printf("%d^2 = %d\n", i, i * i);
    }

    return 0;
}
