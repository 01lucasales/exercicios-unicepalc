// LGRS-14.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-14 - Tipo de Triangulo                     *\n");
    printf("************************************************************\n\n");

    float a, b, c;

    printf("Digite o primeiro lado do triangulo: ");
    scanf("%f", &a);
    printf("Digite o segundo lado do triangulo: ");
    scanf("%f", &b);
    printf("Digite o terceiro lado do triangulo: ");
    scanf("%f", &c);

    if (a == b && b == c) {
        printf("\nTriangulo EQUILATERO (todos os lados iguais).\n");
    } else if (a == b || b == c || a == c) {
        printf("\nTriangulo ISOSCELES (dois lados iguais).\n");
    } else {
        printf("\nTriangulo ESCALENO (todos os lados diferentes).\n");
    }

    return 0;
}
