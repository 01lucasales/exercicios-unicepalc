// LGRS-38.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-38 - Senha Correta (while)                 *\n");
    printf("************************************************************\n\n");

    char senha[50];
    char senhaCorreta[] = "acesso123";

    printf("Digite a senha: ");
    scanf("%s", senha);

    while (strcmp(senha, senhaCorreta) != 0) {
        printf("Senha incorreta! Tente novamente: ");
        scanf("%s", senha);
    }

    printf("\nAcesso LIBERADO!\n");

    return 0;
}
