// LGRS-25.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-25 - Notas e Aprovacao                     *\n");
    printf("************************************************************\n\n");

    float media;

    printf("Digite a media final do aluno: ");
    scanf("%f", &media);

    if (media >= 7.0) {
        printf("\nAluno APROVADO! Media: %.2f\n", media);
    } else if (media >= 5.0) {
        printf("\nAluno em RECUPERACAO. Media: %.2f\n", media);
    } else {
        printf("\nAluno REPROVADO. Media: %.2f\n", media);
    }

    return 0;
}
