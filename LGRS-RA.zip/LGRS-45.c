// LGRS-45.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-45 - Menu ate Escolher Sair (while)        *\n");
    printf("************************************************************\n\n");

    int opcao;

    do {
        printf("\n=== MENU ===\n");
        printf("1 - Opcao A\n");
        printf("2 - Opcao B\n");
        printf("3 - Opcao C\n");
        printf("0 - Sair\n");
        printf("Escolha: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1: printf("Voce escolheu a Opcao A.\n"); break;
            case 2: printf("Voce escolheu a Opcao B.\n"); break;
            case 3: printf("Voce escolheu a Opcao C.\n"); break;
            case 0: printf("Saindo do sistema...\n"); break;
            default: printf("Opcao invalida!\n");
        }
    } while (opcao != 0);

    return 0;
}
