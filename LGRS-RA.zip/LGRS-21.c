// LGRS-21.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-21 - Numero Positivo ou Negativo           *\n");
    printf("************************************************************\n\n");

    float numero;

    printf("Digite um numero: ");
    scanf("%f", &numero);

    if (numero > 0) {
        printf("\nO numero %.2f e POSITIVO (Lucro).\n", numero);
    } else if (numero < 0) {
        printf("\nO numero %.2f e NEGATIVO (Prejuizo).\n", numero);
    } else {
        printf("\nO numero e ZERO.\n");
    }

    return 0;
}
