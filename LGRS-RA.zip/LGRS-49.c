// LGRS-49.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-49 - Pedir Senha ate Acertar (do...while)  *\n");
    printf("************************************************************\n\n");

    int senha;

    do {
        printf("Digite a senha: ");
        scanf("%d", &senha);

        if (senha != 1111) {
            printf("Senha incorreta! Tente novamente.\n");
        }
    } while (senha != 1111);

    printf("\nAcesso liberado!\n");

    return 0;
}
