// LGRS-35.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-35 - Sequencia de Fibonacci (for)          *\n");
    printf("************************************************************\n\n");

    int n, i;
    long long a = 0, b = 1, temp;

    printf("Quantos termos de Fibonacci deseja exibir? ");
    scanf("%d", &n);

    printf("\nSequencia de Fibonacci com %d termos:\n", n);
    for (i = 0; i < n; i++) {
        printf("%lld\n", a);
        temp = a + b;
        a = b;
        b = temp;
    }

    return 0;
}
