// LGRS-44.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-44 - Contar Digitos de um Numero (while)   *\n");
    printf("************************************************************\n\n");

    long long numero;
    int digitos = 0;

    printf("Digite um numero positivo: ");
    scanf("%lld", &numero);

    if (numero == 0) {
        digitos = 1;
    } else {
        long long temp = numero;
        while (temp != 0) {
            temp /= 10;
            digitos++;
        }
    }

    printf("\nO numero %lld possui %d digito(s).\n", numero, digitos);

    return 0;
}
