// LGRS-24.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-24 - Pode Votar?                           *\n");
    printf("************************************************************\n\n");

    int idade;

    printf("Digite sua idade: ");
    scanf("%d", &idade);

    if (idade >= 16) {
        printf("\nVoce PODE votar!\n");
    } else {
        printf("\nVoce NAO pode votar ainda. Idade minima: 16 anos.\n");
    }

    return 0;
}
