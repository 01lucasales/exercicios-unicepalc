// LGRS-39.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-39 - Numero Positivo Obrigatorio (while)   *\n");
    printf("************************************************************\n\n");

    float numero;

    printf("Digite um numero positivo: ");
    scanf("%f", &numero);

    while (numero <= 0) {
        printf("Valor invalido! Digite um numero positivo: ");
        scanf("%f", &numero);
    }

    printf("\nNumero positivo aceito: %.2f\n", numero);

    return 0;
}
