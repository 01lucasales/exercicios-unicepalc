// LGRS-26.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-26 - Contar de 1 a 10 (for)                *\n");
    printf("************************************************************\n\n");

    int i;

    printf("Contagem de 1 a 10:\n");
    for (i = 1; i <= 10; i++) {
        printf("%d\n", i);
    }

    return 0;
}
