// LGRS-33.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-33 - Multiplos de 3 entre 1 e 30 (for)     *\n");
    printf("************************************************************\n\n");

    int i;

    printf("Multiplos de 3 entre 1 e 30:\n");
    for (i = 3; i <= 30; i += 3) {
        printf("%d\n", i);
    }

    return 0;
}
