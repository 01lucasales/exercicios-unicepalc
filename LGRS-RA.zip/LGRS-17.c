// LGRS-17.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-17 - O Sensor do Parque Tematico           *\n");
    printf("************************************************************\n\n");

    float altura;

    printf("Digite a altura da crianca em centimetros: ");
    scanf("%f", &altura);

    if (altura >= 140) {
        printf("\nLUZ VERDE - Acesso LIBERADO! Divirta-se!\n");
    } else {
        printf("\nLUZ VERMELHA - Acesso BARRADO! Altura minima: 140 cm.\n");
    }

    return 0;
}
