// LGRS-30.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-30 - Fatorial de um Numero (for)           *\n");
    printf("************************************************************\n\n");

    int numero, i;
    long long fatorial = 1;

    printf("Digite um numero para calcular o fatorial: ");
    scanf("%d", &numero);

    if (numero < 0) {
        printf("\nNao existe fatorial de numero negativo.\n");
    } else {
        for (i = 1; i <= numero; i++) {
            fatorial *= i;
        }
        printf("\n%d! = %lld\n", numero, fatorial);
    }

    return 0;
}
