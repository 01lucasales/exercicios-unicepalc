// LGRS-31.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-31 - Contagem Regressiva (for)             *\n");
    printf("************************************************************\n\n");

    int i;

    printf("Contagem regressiva:\n");
    for (i = 10; i >= 1; i--) {
        printf("%d\n", i);
    }
    printf("VAI!\n");

    return 0;
}
