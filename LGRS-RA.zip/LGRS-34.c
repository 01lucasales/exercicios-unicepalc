// LGRS-34.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-34 - Verificar se e Primo (for)            *\n");
    printf("************************************************************\n\n");

    int numero, i, primo = 1;

    printf("Digite um numero: ");
    scanf("%d", &numero);

    if (numero < 2) {
        primo = 0;
    } else {
        for (i = 2; i < numero; i++) {
            if (numero % i == 0) {
                primo = 0;
                break;
            }
        }
    }

    if (primo) {
        printf("\nO numero %d E PRIMO.\n", numero);
    } else {
        printf("\nO numero %d NAO e primo.\n", numero);
    }

    return 0;
}
