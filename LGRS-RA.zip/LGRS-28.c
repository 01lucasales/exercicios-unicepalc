// LGRS-28.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-28 - Soma dos 100 Primeiros Naturais (for) *\n");
    printf("************************************************************\n\n");

    int i, soma = 0;

    for (i = 1; i <= 100; i++) {
        soma += i;
    }

    printf("A soma dos numeros de 1 a 100 e: %d\n", soma);

    return 0;
}
