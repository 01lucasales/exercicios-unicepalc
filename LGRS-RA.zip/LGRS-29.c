// LGRS-29.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-29 - Numeros Pares de 0 a 50 (for)         *\n");
    printf("************************************************************\n\n");

    int i;

    printf("Numeros pares entre 0 e 50:\n");
    for (i = 0; i <= 50; i += 2) {
        printf("%d\n", i);
    }

    return 0;
}
