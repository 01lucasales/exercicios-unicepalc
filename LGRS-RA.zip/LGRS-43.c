// LGRS-43.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-43 - Soma dos Pares entre 1 e 100 (while)  *\n");
    printf("************************************************************\n\n");

    int i = 2, soma = 0;

    while (i <= 100) {
        soma += i;
        i += 2;
    }

    printf("Soma de todos os numeros pares entre 1 e 100: %d\n", soma);

    return 0;
}
