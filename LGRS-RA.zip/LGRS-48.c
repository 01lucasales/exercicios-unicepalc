// LGRS-48.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-48 - Menu com Opcao de Sair (do...while)   *\n");
    printf("************************************************************\n\n");

    int opcao;

    do {
        printf("\n=== MENU ===\n");
        printf("1 - Mensagem\n");
        printf("2 - Sair\n");
        printf("Escolha: ");
        scanf("%d", &opcao);

        if (opcao == 1) {
            printf("Voce escolheu a mensagem!\n");
        } else if (opcao == 2) {
            printf("Saindo...\n");
        } else {
            printf("Opcao invalida!\n");
        }
    } while (opcao != 2);

    return 0;
}
