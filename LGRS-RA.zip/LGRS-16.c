// LGRS-16.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-16 - Multiplo de 3 e/ou 5                  *\n");
    printf("************************************************************\n\n");

    int pedido;

    printf("Digite o numero do pedido: ");
    scanf("%d", &pedido);

    if (pedido % 3 == 0 && pedido % 5 == 0) {
        printf("\nParabens! Voce ganhou um REFRIGERANTE e uma SOBREMESA!\n");
    } else if (pedido % 3 == 0) {
        printf("\nParabens! Voce ganhou um REFRIGERANTE!\n");
    } else if (pedido % 5 == 0) {
        printf("\nParabens! Voce ganhou uma SOBREMESA!\n");
    } else {
        printf("\nSem brinde desta vez. Bom apetite!\n");
    }

    return 0;
}
