// LGRS-53.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-53 - Confirmar Saida com 's' (do...while)  *\n");
    printf("************************************************************\n\n");

    char resposta;

    do {
        printf("\n=== SISTEMA DE CADASTRO ===\n");
        printf("Operacao realizada com sucesso!\n");
        printf("Deseja sair? (s para sair / qualquer tecla para continuar): ");
        scanf(" %c", &resposta);
    } while (resposta != 's');

    printf("\nSistema encerrado. Ate logo!\n");

    return 0;
}
