// LGRS-23.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-23 - Maior de Dois Numeros                 *\n");
    printf("************************************************************\n\n");

    float a, b;

    printf("Digite a pontuacao do primeiro atleta: ");
    scanf("%f", &a);
    printf("Digite a pontuacao do segundo atleta: ");
    scanf("%f", &b);

    if (a > b) {
        printf("\nA maior pontuacao e: %.2f (Atleta 1).\n", a);
    } else if (b > a) {
        printf("\nA maior pontuacao e: %.2f (Atleta 2).\n", b);
    } else {
        printf("\nAmbos os atletas tiveram a mesma pontuacao: %.2f.\n", a);
    }

    return 0;
}
