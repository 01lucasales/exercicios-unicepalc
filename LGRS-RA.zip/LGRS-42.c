// LGRS-42.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-42 - Qtd de Impares Digitados (while)      *\n");
    printf("************************************************************\n\n");

    int numero, i = 0, contImpar = 0;

    printf("Digite 10 numeros:\n");
    while (i < 10) {
        printf("Numero %d: ", i + 1);
        scanf("%d", &numero);
        if (numero % 2 != 0) {
            contImpar++;
        }
        i++;
    }

    printf("\nQuantidade de numeros impares: %d\n", contImpar);

    return 0;
}
