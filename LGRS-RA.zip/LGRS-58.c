// LGRS-58.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-58 - Calculadora de Bolso (switch)         *\n");
    printf("************************************************************\n\n");

    float a, b;
    char op;

    printf("Digite o primeiro numero: ");
    scanf("%f", &a);
    printf("Digite o operador (+, -, *, /): ");
    scanf(" %c", &op);
    printf("Digite o segundo numero: ");
    scanf("%f", &b);

    switch (op) {
        case '+':
            printf("\nResultado: %.2f + %.2f = %.2f\n", a, b, a + b);
            break;
        case '-':
            printf("\nResultado: %.2f - %.2f = %.2f\n", a, b, a - b);
            break;
        case '*':
            printf("\nResultado: %.2f * %.2f = %.2f\n", a, b, a * b);
            break;
        case '/':
            if (b == 0) {
                printf("\nErro: divisao por zero!\n");
            } else {
                printf("\nResultado: %.2f / %.2f = %.2f\n", a, b, a / b);
            }
            break;
        default:
            printf("\nOperacao matematica nao reconhecida.\n");
    }

    return 0;
}
