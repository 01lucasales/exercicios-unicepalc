// LGRS-46.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-46 - Contar de 1 a 10 (do...while)         *\n");
    printf("************************************************************\n\n");

    int i = 1;

    printf("Contagem de 1 a 10:\n");
    do {
        printf("%d\n", i);
        i++;
    } while (i <= 10);

    return 0;
}
