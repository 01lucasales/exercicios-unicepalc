// LGRS-50.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-50 - Numero Positivo Obrigatorio (do...while)*\n");
    printf("************************************************************\n\n");

    float numero;

    do {
        printf("Digite um valor positivo para deposito: ");
        scanf("%f", &numero);

        if (numero <= 0) {
            printf("Valor invalido! Apenas valores positivos sao aceitos.\n");
        }
    } while (numero <= 0);

    printf("\nDeposito de R$ %.2f realizado com sucesso!\n", numero);

    return 0;
}
