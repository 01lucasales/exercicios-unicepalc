// LGRS-59.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-59 - Assistente de Direcao (switch)        *\n");
    printf("************************************************************\n\n");

    char direcao;

    printf("Digite a letra da direcao (N, S, L, O): ");
    scanf(" %c", &direcao);

    switch (direcao) {
        case 'N':
            printf("\nSeguir para o Norte.\n");
            break;
        case 'S':
            printf("\nSeguir para o Sul.\n");
            break;
        case 'L':
            printf("\nVirar a Leste (Direita).\n");
            break;
        case 'O':
            printf("\nVirar a Oeste (Esquerda).\n");
            break;
        default:
            printf("\nComando invalido! Pare o robo.\n");
    }

    return 0;
}
