// LGRS-54.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-54 - Validar Numero entre 1 e 5 (do...while)*\n");
    printf("************************************************************\n\n");

    int nivel;

    do {
        printf("Escolha o nivel de dificuldade (1 a 5): ");
        scanf("%d", &nivel);

        if (nivel < 1 || nivel > 5) {
            printf("Nivel invalido! Escolha entre 1 e 5.\n");
        }
    } while (nivel < 1 || nivel > 5);

    printf("\nNivel %d selecionado! Boa sorte!\n", nivel);

    return 0;
}
