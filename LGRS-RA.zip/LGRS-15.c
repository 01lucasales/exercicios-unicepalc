// LGRS-15.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-15 - Quantas caixas cabem no caminhao      *\n");
    printf("************************************************************\n\n");

    float altCam, largCam, compCam;
    float altCaixa, largCaixa, compCaixa;
    int qtd;

    printf("=== Dimensoes do Caminhao ===\n");
    printf("Altura (m): ");
    scanf("%f", &altCam);
    printf("Largura (m): ");
    scanf("%f", &largCam);
    printf("Comprimento (m): ");
    scanf("%f", &compCam);

    printf("\n=== Dimensoes da Caixa ===\n");
    printf("Altura (m): ");
    scanf("%f", &altCaixa);
    printf("Largura (m): ");
    scanf("%f", &largCaixa);
    printf("Comprimento (m): ");
    scanf("%f", &compCaixa);

    int qtdAltura  = (int)(altCam  / altCaixa);
    int qtdLargura = (int)(largCam / largCaixa);
    int qtdComp    = (int)(compCam / compCaixa);

    qtd = qtdAltura * qtdLargura * qtdComp;

    printf("\nCabem %d caixas no caminhao.\n", qtd);

    return 0;
}
