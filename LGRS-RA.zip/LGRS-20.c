// LGRS-20.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-20 - Ano Bissexto                          *\n");
    printf("************************************************************\n\n");

    int ano;

    printf("Digite um ano: ");
    scanf("%d", &ano);

    if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0)) {
        printf("\nO ano %d E BISSEXTO (366 dias).\n", ano);
    } else {
        printf("\nO ano %d NAO e bissexto (365 dias).\n", ano);
    }

    return 0;
}
