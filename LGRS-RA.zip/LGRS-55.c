// LGRS-55.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("************************************************************\n");
    printf("* Aluno: Lucas Gabriel Ribeiro Sales                       *\n");
    printf("* Programa LGRS-55 - Maior Numero ate Digitar Negativo      *\n");
    printf("************************************************************\n\n");

    float numero, maior;
    int primeiro = 1;

    printf("Digite numeros positivos (negativo para encerrar):\n");

    do {
        printf("Numero: ");
        scanf("%f", &numero);

        if (numero >= 0) {
            if (primeiro || numero > maior) {
                maior = numero;
                primeiro = 0;
            }
        }
    } while (numero >= 0);

    if (!primeiro) {
        printf("\nO maior numero positivo digitado foi: %.2f\n", maior);
    } else {
        printf("\nNenhum numero positivo foi digitado.\n");
    }

    return 0;
}
